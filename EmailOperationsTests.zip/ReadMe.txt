This EmailOperationsTests project contains three Selenium WebDriver tests performed on an existing email account - login/logout, login/sending an email/logout, and finally login/sending an email/deleting sent emails/logout.

Created and tested with Visual Studio 2022, NUNit 3.13.3, NUnit.Analyzers 3.6.1, NUnit3TestAdapter 4.4.2, Selenium Support 4.29.0, Selenium WebDriver 4.29.0, Selenium.WebDriver.ChromeDriver 133.0.6943.12600 and Google Chrome browser version 133.0.6943.127 64-bit on March 06, 2025.

Note that the email service, the tools used and Google Chrome may (and very likely will) change in the future and these tests may not run properly anymore.

In any case you may take a look to see how they were implemented.

Thank you for your attention!

Alexander Yovchev