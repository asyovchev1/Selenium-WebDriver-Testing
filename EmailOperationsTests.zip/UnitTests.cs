using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace EmailOperationsTests
{
    //README: These tests simulate working with an email account. Due to the fact that the free Proton Email service works rather slowly for some reason, a number of waits had to be inserted to make sure the email service can complete the user actions

    public class Tests
    {
        private readonly static string BaseUrl = "https://account.proton.me/mail";
        private WebDriver driver;

        [OneTimeSetUp]
        public void Setup()
        {
            driver = new ChromeDriver();
        }

        [Test, Order(1)]
        public void LoginLogoutTest()
        {
            //open browser
            driver.Navigate().GoToUrl(BaseUrl);
            driver.Manage().Window.Maximize();

            //enter login credentials
            driver.FindElement(By.XPath("//input[@id='username']")).SendKeys("testasyovchev1");
            driver.FindElement(By.XPath("//input[@id='password']")).SendKeys("c5n597ng%MA");
            driver.FindElement(By.XPath("//button[text()='Sign in']")).Click();

            //wait for service to appear
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(65);
            driver.FindElement(By.XPath("//div[text()='Proton Mail']")).Click();

            //wait for all inbox components to load and log out
            Task.Delay(10000).Wait();
            driver.FindElement(By.XPath("//span[text()='testasyovchev1']")).Click();
            driver.FindElement(By.XPath("//button[text()='Sign out']")).Click();
        }

        [Test, Order(2)]
        public void SendEmailTest()
        {
            //open browser
            driver.Navigate().GoToUrl(BaseUrl);
            driver.Manage().Window.Maximize();

            //enter login credentials
            driver.FindElement(By.XPath("//input[@id='username']")).SendKeys("testasyovchev1");
            driver.FindElement(By.XPath("//input[@id='password']")).SendKeys("c5n597ng%MA");
            driver.FindElement(By.XPath("//button[text()='Sign in']")).Click();

            //wait for service to appear
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(65);

            //create new message
            driver.FindElement(By.XPath("//button[text()='New message']")).Click();

            //enter email information
            driver.FindElement(By.XPath("//input[contains(@id,'to-composer')]")).SendKeys("asyovchev1@gmail.com");
            driver.FindElement(By.XPath("//input[contains(@id,'subject-composer')]")).SendKeys("test");
            driver.FindElement(By.XPath("//*[contains(@class,'w-full h-full editor-textarea')]")).SendKeys("test test test");

            //send email and wait for confirmation
            driver.FindElement(By.XPath("//*[contains(@class,'px-4 hidden md:inline')]")).Click();
            Task.Delay(10000).Wait();

            //log out
            driver.FindElement(By.XPath("//span[text()='testasyovchev1']")).Click();
            driver.FindElement(By.XPath("//button[text()='Sign out']")).Click();
        }

        [Test, Order(3)]
        public void SendAndDeleteEmailTest()
        {
            //open browser
            driver.Navigate().GoToUrl(BaseUrl);
            driver.Manage().Window.Maximize();

            //enter login credentials
            driver.FindElement(By.XPath("//input[@id='username']")).SendKeys("testasyovchev1");
            driver.FindElement(By.XPath("//input[@id='password']")).SendKeys("c5n597ng%MA");
            driver.FindElement(By.XPath("//button[text()='Sign in']")).Click();

            //wait for service to appear
            driver.Manage().Timeouts().ImplicitWait = TimeSpan.FromSeconds(65);

            //create new message
            driver.FindElement(By.XPath("//button[text()='New message']")).Click();

            //enter email information
            driver.FindElement(By.XPath("//input[contains(@id,'to-composer')]")).SendKeys("asyovchev1@gmail.com");
            driver.FindElement(By.XPath("//input[contains(@id,'subject-composer')]")).SendKeys("test");
            driver.FindElement(By.XPath("//*[contains(@class,'w-full h-full editor-textarea')]")).SendKeys("test test test");

            //send email and wait for confirmation
            driver.FindElement(By.XPath("//span[contains(@class,'px-4 hidden md:inline')]")).Click();
            Task.Delay(10000).Wait();

            //go to Sent folder and wait for sent emails to load
            driver.FindElement(By.XPath("(//span[@class='text-ellipsis'])[3]")).Click();
            Task.Delay(10000).Wait();

            //select all sent emails and wait for functional options to appear
            driver.FindElement(By.XPath("//input[@id='idSelectAll']")).Click();
            Task.Delay(10000).Wait();

            //move sent emails to trash folder and wait for them to be moved
            driver.FindElement(By.XPath("(//button[contains(@class, 'flex shrink-0 toolbar-button')])[2]")).Click();
            Task.Delay(10000).Wait();

            //go to trash folder and wait for emails in trash to load
            driver.FindElement(By.XPath("(//span[contains(@class, 'flex-1 max-w-full flex items-center flex-nowrap gap-2')])[4]")).Click();
            Task.Delay(10000).Wait();

            //select all emails in trash and wait for functional options to appear
            driver.FindElement(By.XPath("//input[@id='idSelectAll']")).Click();
            Task.Delay(10000).Wait();

            //delete emails in trash permanently, confirm the action and wait for emails to be deleted
            driver.FindElement(By.XPath("(//button[contains(@class, 'flex shrink-0 toolbar-button')])[4]")).Click();
            driver.FindElement(By.XPath("//button[contains(@class, 'button w-full button-medium button-solid-danger')]")).Click();
            Task.Delay(10000).Wait();

            //log out
            driver.FindElement(By.XPath("//span[text()='testasyovchev1']")).Click();
            driver.FindElement(By.XPath("//button[text()='Sign out']")).Click();
        }

        [OneTimeTearDown]
        public void TearDown()
        {
            driver.Quit();
            driver.Dispose();
        }
    }
}